package worldofzuul;

public class User {

    public void pickUpObject ()
    {

    }

    public void dropObject ()
    {

    }

    public void move ()
    {

    }

    public void combine ()
    {

    }

}

package worldofzuul;

public class NPC {

    public void communicate ()
    {

    }

    public void recieveObject ()
    {

    }

    public void giveObject ()
    {

    }

}
